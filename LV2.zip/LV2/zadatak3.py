import numpy as np
import matplotlib.pyplot as plt


slika = plt.imread("tiger.png")
slika= slika[:, :, 0] if slika.ndim == 3 else slika


posvijetljenja_slika = np.clip(slika + 50, 0, 255)        
rotirana_slika= np.rot90(slika, -1)               
zrcaljena_slika = np.fliplr(slika)                 
smanjena_slika = slika[::10, ::10]                   
masked_slika = np.zeros_like(slika)               
masked_slika[:, slika.shape[1]//4:slika.shape[1]//2] = slika[:, slika.shape[1]//4:slika.shape[1]//2]


titles = ["Original", "Svjetlija", "Rotirana", "Zrcaljena", "Smanjena", "Druga četvrtina"]
images = [slika, posvijetljenja_slika, rotirana_slika, zrcaljena_slika, smanjena_slika, masked_slika]

plt.figure(figsize=(10, 6))
for i in range(6):
    plt.subplot(2, 3, i + 1)
    plt.imshow(images[i], cmap="gray")
    plt.title(titles[i])
    plt.axis("off")

plt.tight_layout()
plt.show()