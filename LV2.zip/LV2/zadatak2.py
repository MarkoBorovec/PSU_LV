import numpy as np
import matplotlib.pyplot as plt


data = np.loadtxt(open("mtcars.csv", "rb"), usecols=(1,2,3,4,5,6),delimiter=",", skiprows=1)

mpg = data[:, 0]   
cyl = data[:, 1]   
hp = data[:, 2]    
wt = data[:, 4]    


plt.figure(figsize=(8,6))
plt.scatter(hp, mpg, s=wt*30, color='red', alpha=0.6, edgecolors='black')
plt.xlabel("Konjske snage (hp)")
plt.ylabel("Potrosnja goriva (mpg)")
plt.title("Ovisnost potrosnje goriva o konjskim snagama")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()


mpg_min = np.min(mpg)
mpg_max = np.max(mpg)
mpg_mean = np.mean(mpg)

print(f"Minimalna potrosnja goriva: {mpg_min:.2f} mpg")
print(f"Maksimalna potrosnja goriva: {mpg_max:.2f} mpg")
print(f"Srednja potrosnja goriva: {mpg_mean:.2f} mpg")


mpg_6cyl = mpg[cyl == 6]

mpg_6cyl_min = np.min(mpg_6cyl)
mpg_6cyl_max = np.max(mpg_6cyl)
mpg_6cyl_mean = np.mean(mpg_6cyl)

print("\nZa automobile sa 6 cilindara:")
print(f"Minimalna potrosnja goriva: {mpg_6cyl_min:.2f} mpg")
print(f"Maksimalna potrosnja goriva: {mpg_6cyl_max:.2f} mpg")
print(f"Srednja potrosnja goriva: {mpg_6cyl_mean:.2f} mpg")