import pandas as pd
import matplotlib.pyplot as plt

mtcars = pd.read_csv('mtcars.csv', index_col='car')
plt.figure(figsize=(14, 10))
plt.subplot(2, 2, 1)
mpg_cyl = mtcars.groupby('cyl')['mpg'].mean()
plt.bar(mpg_cyl.index, mpg_cyl.values, color=['blue', 'deepskyblue', 'skyblue'])
plt.title('Potrosnja automobila s 4, 6 i 8 cilindara')
plt.xlabel('Broj cilindara')
plt.ylabel('Potrosnja (mpg)')

plt.subplot(2, 2, 2)
plt.boxplot([mtcars[mtcars['cyl'] == 4]['wt'], 
             mtcars[mtcars['cyl'] == 6]['wt'], 
             mtcars[mtcars['cyl'] == 8]['wt']], 
            labels=['4 cilindra', '6 cilindra', '8 cilindra'])
plt.title('Distribucija težine automobila s 4, 6 i 8 cilindara')
plt.xlabel('Broj cilindara')
plt.ylabel('Težina (1000 lbs)')

plt.subplot(2, 2, 3)
plt.boxplot([mtcars[mtcars['am'] == 0]['mpg'], 
             mtcars[mtcars['am'] == 1]['mpg']], 
            labels=['Automatski', 'Rucni'])
plt.title('Potrosnja automobila s rucnim i automatskim mjenjacem')
plt.xlabel('Vrsta mjenjaca')
plt.ylabel('Potrosnja (mpg)')

plt.subplot(2, 2, 4)
plt.scatter(mtcars[mtcars['am'] == 0]['hp'], mtcars[mtcars['am'] == 0]['qsec'], color='red', label='Automatski')
plt.scatter(mtcars[mtcars['am'] == 1]['hp'], mtcars[mtcars['am'] == 1]['qsec'], color='blue', label='Rucni')
plt.title('Odnos ubrzanja i snage automobila')
plt.xlabel('Snaga (hp)')
plt.ylabel('Ubrzanje (qsec)')
plt.legend()

plt.tight_layout()
plt.show()
