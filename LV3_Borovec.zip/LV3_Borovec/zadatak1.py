import pandas as pd

mtcars = pd.read_csv('mtcars.csv', index_col='car')
Najveca_potrosnja = mtcars.sort_values(by='mpg', ascending=False).head(5)
print("5 automobila s najvecom potrosnjom:")
print(Najveca_potrosnja[['mpg']])
Najmanja_potrosnja = mtcars[mtcars['cyl'] == 8].sort_values(by='mpg').head(3)
print("\nTri automobila s 8 cilindara i najmanjom potrosnjom:")
print(Najmanja_potrosnja[['mpg']])

Srednja_potrosnja6 = mtcars[mtcars['cyl'] == 6]['mpg'].mean()
print(f"\nSrednja potrosnja automobila sa 6 cilindara: {Srednja_potrosnja6:.2f}")


Srednja_potrosnja4 = mtcars[(mtcars['cyl'] == 4) & (mtcars['wt'] >= 2.000) & (mtcars['wt'] <= 2.200)]['mpg'].mean()
print(f"\nSrednja potrosnja automobila s 4 cilindra i mase između 2000 i 2200 lbs: {Srednja_potrosnja4:.2f}")

broj_mjenjaca = mtcars['am'].value_counts()
print(f"\nBroj automobila s rucnim i automatskim mjenjacem:")
print(broj_mjenjaca)

brojac_automatic = mtcars[(mtcars['am'] == 1) & (mtcars['hp'] > 100)].shape[0]
print(f"\nBroj automobila s automatskim mjenjacem i snagom preko 100hp: {brojac_automatic}")

mtcars['wt_kg'] = mtcars['wt'] * 0.453592
print("\nMasa svakog automobila u kilogramima:")
print(mtcars[['wt', 'wt_kg']])
