import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split


df = pd.read_csv('cars_processed.csv')

X = df[['km_driven']]
y = df['selling_price']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


degrees = [2, 6, 15]
MSEtrain = []
MSEtest = []
plt.figure(figsize=(10, 6))


X_plot = np.linspace(X.min(), X.max(), 100).reshape(-1, 1)

for degree in degrees:
  
    poly = PolynomialFeatures(degree=degree)
    X_train_poly = poly.fit_transform(X_train)
    X_test_poly = poly.transform(X_test)
    X_plot_poly = poly.transform(X_plot)
    
    
    model = LinearRegression()
    model.fit(X_train_poly, y_train)
    
   
    y_train_pred = model.predict(X_train_poly)
    y_test_pred = model.predict(X_test_poly)
    y_plot_pred = model.predict(X_plot_poly)
    
  
    MSEtrain.append(mean_squared_error(y_train, y_train_pred))
    MSEtest.append(mean_squared_error(y_test, y_test_pred))
    
  
    plt.plot(X_plot, y_plot_pred, label=f'Degree {degree}')


plt.scatter(X_train, y_train, color='blue', alpha=0.5, label='Training Data')
plt.scatter(X_test, y_test, color='red', alpha=0.5, label='Testing Data')
plt.xlabel('Kilometraža')
plt.ylabel('Cijena')
plt.legend()
plt.title('Usporedba modela različitih stupnjeva polinoma')
plt.show()

print("MSE na podacima za učenje:", MSEtrain)
print("MSE na podacima za testiranje:", MSEtest)
